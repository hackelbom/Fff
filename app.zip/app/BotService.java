package com.example.pyhost;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import androidx.core.app.NotificationCompat;
import com.chaquo.python.PyObject;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.io.File;

public class BotService extends Service {
    public static final String CHANNEL_ID = "PyBotServiceChannel";
    private Thread botThread;
    private boolean isRunning = false;

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String action = intent != null ? intent.getAction() : null;

        if ("STOP".equals(action)) {
            stopBot();
            stopSelf();
            return START_NOT_STICKY;
        }

        Notification notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Python Bot Host")
                .setContentText("বট ব্যাকগ্রাউন্ডে চলছে...")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .build();

        startForeground(1, notification);
        startBot();

        return START_STICKY;
    }

    private void startBot() {
        if (isRunning) return;
        isRunning = true;

        botThread = new Thread(() -> {
            if (!Python.isStarted()) {
                Python.start(new AndroidPlatform(getApplicationContext()));
            }
            Python py = Python.getInstance();
            File botFile = new File(getFilesDir(), "bot.py");

            if (botFile.exists()) {
                try {
                    // Python রানার দিয়ে ফাইলটি এক্সিকিউট করা
                    PyObject sys = py.getModule("sys");
                    sys.get("path").callAttr("append", getFilesDir().getAbsolutePath());
                    py.getModule("builtins").callAttr("exec", new java.util.Scanner(botFile).useDelimiter("\\A").next());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
        botThread.start();
    }

    private void stopBot() {
        isRunning = false;
        if (botThread != null && botThread.isAlive()) {
            botThread.interrupt();
        }
    }

    @Override
    public void onDestroy() {
        stopBot();
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Bot Service Channel",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(serviceChannel);
            }
        }
    }
}
